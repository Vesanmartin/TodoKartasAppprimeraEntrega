package com.example.login001v.data.model

data class QrResult(val content: String)